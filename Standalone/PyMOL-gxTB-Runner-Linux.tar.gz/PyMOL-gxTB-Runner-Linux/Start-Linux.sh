#!/usr/bin/env bash
set -euo pipefail

LOCAL_IMAGE="pymol-gxtb-runner:v10"
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKDIR="${1:-"$HOME/pymol-gxtb-work"}"
mkdir -p "$WORKDIR"

echo "Starting PyMOL g-xTB Runner..."
echo "Work folder: $WORKDIR"
echo "Image: $LOCAL_IMAGE"
echo "Platform: linux/amd64"

if ! docker info >/dev/null 2>&1; then
  echo "Docker does not seem to be running, or your user cannot access it."
  echo "Start Docker Desktop or add your user to the docker group."
  exit 1
fi

if docker image inspect "$LOCAL_IMAGE" >/dev/null 2>&1; then
  echo "Using existing local image: $LOCAL_IMAGE"
else
  echo "Building the Docker image locally. This can take several minutes the first time."
  docker build --platform linux/amd64 -t "$LOCAL_IMAGE" "$ROOT_DIR"
fi

(xdg-open http://localhost:6080/vnc.html >/dev/null 2>&1 || true) &

docker rm -f pymol-gxtb-runner >/dev/null 2>&1 || true

docker run --rm -it \
  --platform linux/amd64 \
  --name pymol-gxtb-runner \
  -p 6080:6080 \
  -v "$WORKDIR:/work" \
  -e RESOLUTION=1600x1000x24 \
  -e PYMOL_GXTB_XTB_PATH=/usr/local/bin/gxtb-xtb \
  "$LOCAL_IMAGE"
