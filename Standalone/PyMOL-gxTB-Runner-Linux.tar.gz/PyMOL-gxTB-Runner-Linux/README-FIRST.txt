Linux instructions

1. Install and start Docker.
2. Run: ./Start-Linux.sh

PyMOL g-xTB Runner container package

This version explicitly loads the plugin at PyMOL startup and opens the plugin window automatically.

The container includes:
- open-source PyMOL
- PyMOL g-xTB Runner plugin
- official g-xTB 2.0.1 Linux x86_64 binary as /usr/local/bin/gxtb-xtb
- conda-forge xTB as optional fallback
- ASE, Sella, NumPy, SciPy, matplotlib

This package uses a versioned local Docker image tag:
  pymol-gxtb-runner:v10

So it will not accidentally reuse older broken images tagged as pymol-gxtb-runner:local.

The first launch builds a local Docker image and can take several minutes.
