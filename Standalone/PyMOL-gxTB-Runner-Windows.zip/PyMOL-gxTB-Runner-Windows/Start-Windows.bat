@echo off
setlocal
set LOCAL_IMAGE=pymol-gxtb-runner:v10
set ROOT_DIR=%~dp0
set WORKDIR=%USERPROFILE%\pymol-gxtb-work

if not exist "%WORKDIR%" mkdir "%WORKDIR%"

echo Starting PyMOL g-xTB Runner...
echo Work folder: %WORKDIR%
echo Image: %LOCAL_IMAGE%
echo Platform: linux/amd64
echo.

docker info >nul 2>&1
if errorlevel 1 (
  echo Docker Desktop does not seem to be running.
  echo Please open Docker Desktop, wait until it is running, and try again.
  pause
  exit /b 1
)

docker image inspect %LOCAL_IMAGE% >nul 2>&1
if errorlevel 1 (
  echo Building the Docker image locally. This can take several minutes the first time.
  docker build --platform linux/amd64 -t %LOCAL_IMAGE% "%ROOT_DIR%"
  if errorlevel 1 (
    echo Local Docker build failed.
    pause
    exit /b 1
  )
) else (
  echo Using existing local image: %LOCAL_IMAGE%
)

docker rm -f pymol-gxtb-runner >nul 2>&1

start "" http://localhost:6080/vnc.html

docker run --rm -it ^
  --platform linux/amd64 ^
  --name pymol-gxtb-runner ^
  -p 6080:6080 ^
  -v "%WORKDIR%:/work" ^
  -e RESOLUTION=1600x1000x24 ^
  -e PYMOL_GXTB_XTB_PATH=/usr/local/bin/gxtb-xtb ^
  %LOCAL_IMAGE%

pause
