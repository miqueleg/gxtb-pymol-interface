PyMOL g-xTB Runner — Windows

QUICK START

1. Install Docker Desktop:
   https://www.docker.com/products/docker-desktop/

2. Open Docker Desktop and wait until it says it is running.

3. Extract this ZIP file.

4. Open the extracted folder and double-click:
   Start-Windows.bat

5. Your browser should open:
   http://localhost:6080/vnc.html

WORK FOLDER

Your files go here:
   C:\Users\<your-user>\pymol-gxtb-work

Inside PyMOL/container, this folder appears as:
   /work

NOTES

The first launch builds a local Docker image. This can take several minutes.
Later launches are faster.

This version uses the local Docker image tag:
   pymol-gxtb-runner:v10

It includes:
- PyMOL
- the g-xTB Runner plugin
- g-xTB 2.0.1-capable binary at /usr/local/bin/gxtb-xtb
- ASE
- Sella
- NumPy/SciPy
- xTB fallback from conda-forge
