#!/usr/bin/env bash
set -euo pipefail

export DISPLAY=${DISPLAY:-:1}
export RESOLUTION=${RESOLUTION:-1600x1000x24}
export VNC_PASSWORD=${VNC_PASSWORD:-}
export PATH=/usr/local/bin:/opt/conda/envs/gxtb-pymol/bin:/opt/conda/bin:$PATH
export PYMOL_GXTB_XTB_PATH=${PYMOL_GXTB_XTB_PATH:-/usr/local/bin/gxtb-xtb}

echo "[container] Starting Xvfb on ${DISPLAY} with resolution ${RESOLUTION}"
Xvfb "${DISPLAY}" -screen 0 "${RESOLUTION}" -ac +extension GLX +render -noreset &
sleep 1

echo "[container] Starting fluxbox"
fluxbox >/tmp/fluxbox.log 2>&1 &

if [[ -n "${VNC_PASSWORD}" ]]; then
  echo "[container] Setting VNC password"
  mkdir -p /root/.vnc
  x11vnc -storepasswd "${VNC_PASSWORD}" /root/.vnc/passwd >/dev/null
  VNC_AUTH_ARGS="-rfbauth /root/.vnc/passwd"
else
  VNC_AUTH_ARGS="-nopw"
fi

echo "[container] Starting x11vnc"
x11vnc -display "${DISPLAY}" -forever -shared ${VNC_AUTH_ARGS} -rfbport 5900 >/tmp/x11vnc.log 2>&1 &

echo "[container] Starting noVNC on http://localhost:6080/vnc.html"
websockify --web=/usr/share/novnc/ 6080 localhost:5900 >/tmp/novnc.log 2>&1 &

echo "[container] g-xTB binary:"
command -v gxtb-xtb || true
gxtb-xtb --version || true

echo "[container] Starting PyMOL with plugin loader"
cd /work

if command -v pymol >/dev/null 2>&1; then
  exec pymol -r /opt/pymol-gxtb-runner/load_plugin.py
elif command -v pymol-open-source >/dev/null 2>&1; then
  exec pymol-open-source -r /opt/pymol-gxtb-runner/load_plugin.py
else
  exec python -m pymol -r /opt/pymol-gxtb-runner/load_plugin.py
fi
