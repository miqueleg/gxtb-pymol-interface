import importlib.util
import traceback

PLUGIN_PATH = "/opt/pymol-gxtb-runner/pymol_gxtb_plugin.py"

try:
    spec = importlib.util.spec_from_file_location("pymol_gxtb_plugin", PLUGIN_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    if hasattr(mod, "register_plugin"):
        mod.register_plugin(None)
    elif hasattr(mod, "__init_plugin__"):
        mod.__init_plugin__(None)

    print("[PyMOL g-xTB Runner] plugin loaded from", PLUGIN_PATH)

    try:
        mod.run_plugin_gui()
        print("[PyMOL g-xTB Runner] plugin window opened")
    except Exception as exc:
        print("[PyMOL g-xTB Runner] plugin loaded, but automatic window open failed:", exc)
        traceback.print_exc()
except Exception as exc:
    print("[PyMOL g-xTB Runner] FAILED to load plugin:", exc)
    traceback.print_exc()
